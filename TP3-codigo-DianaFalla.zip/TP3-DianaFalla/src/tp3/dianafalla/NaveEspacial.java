/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tp3.dianafalla;

public class NaveEspacial {
    private String nombre;
    private int combustible;
    private final int CAPACIDAD_MAX = 100; 

    public NaveEspacial(String nombre, int combustibleInicial) {
        this.nombre = nombre;
        if (combustibleInicial > CAPACIDAD_MAX) {
            this.combustible = CAPACIDAD_MAX;
        } else {
            this.combustible = combustibleInicial;
        }
    }
    public void despegar() {
        if (combustible >= 10) {
            combustible -= 10;
            System.out.println(nombre + " despego. Combustible restante: " + combustible);
        } else {
            System.out.println(" No hay suficiente combustible para despegar.");
        }
    }
    public void avanzar(int distancia) {
        int consumo = distancia * 2; 
        if (combustible >= consumo) {
            combustible -= consumo;
            System.out.println(nombre + " avanzo " + distancia + " km. Combustible restante: " + combustible);
        } else {
            System.out.println("Combustible insuficiente para avanzar " + distancia + " km.");
        }
    }
    public void recargarCombustible(int cantidad) {
        if (combustible + cantidad > CAPACIDAD_MAX) {
            combustible = CAPACIDAD_MAX;
            System.out.println("Se recargo al maximo. Combustible actual: " + combustible);
        } else {
            combustible += cantidad;
            System.out.println("Se recargo " + cantidad + " unidades. Combustible actual: " + combustible);
        }
    }
    public void mostrarEstado() {
        System.out.println("Nave: " + nombre);
        System.out.println("Combustible: " + combustible + "/" + CAPACIDAD_MAX);
        System.out.println("--------------------------");
    }
}
