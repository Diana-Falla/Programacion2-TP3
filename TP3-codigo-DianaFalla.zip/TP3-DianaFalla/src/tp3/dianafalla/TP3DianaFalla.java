/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp3.dianafalla;

public class TP3DianaFalla {

    public static void main(String[] args) {
        Estudiante estudiante1 = new Estudiante("Diana", "Falla", "Programacion", 85);

        estudiante1.mostrarInfo();

        estudiante1.subirCalificacion(10);

        estudiante1.bajarCalificacion(20);

        estudiante1.mostrarInfo();
        
//-----Ejercicio 2-------------------------------------------------------------------------------
        // Crear una mascota
        Mascota mascota1 = new Mascota("Firulais", "Perro", 3);

        mascota1.mostrarInfo();

        mascota1.cumplirAnios();
        mascota1.cumplirAnios();

        mascota1.mostrarInfo();
 
//-----Ejercicio 3-------------------------------------------------------------------------------

        Libro libro1 = new Libro("Cien anios de soledad", "Gabriel Garcia Marquez", 1967);

        libro1.mostrarInfo();

        libro1.setAñoPublicacion(3025); 

        libro1.setAñoPublicacion(1982);

        libro1.mostrarInfo();
          
//-----Ejercicio 4-------------------------------------------------------------------------------        

        // Creamos dos gallinas
        Gallina g1 = new Gallina(1, 2);
        Gallina g2 = new Gallina(2, 1);

        g1.ponerHuevo();
        g1.ponerHuevo();
        g1.envejecer();

        g2.ponerHuevo();
        g2.envejecer();
        g2.ponerHuevo();

        g1.mostrarEstado();
        g2.mostrarEstado();
        
//-----Ejercicio 5------------------------------------------
        // Creamos una nave con 50 unidades de combustible
        NaveEspacial nave1 = new NaveEspacial("Apollo", 50);

        nave1.despegar();
        nave1.avanzar(30); 

        // Recargar combustible
        nave1.recargarCombustible(40);

        // Avanzar correctamente
        nave1.avanzar(20);

        // Mostrar estado final
        nave1.mostrarEstado();
    }
}
